import { Component } from '@angular/core';
import { ComunicaComponenteTransformacionService } from '../../servicios/transformacion/comunica-componente-transformacion.service';
import { Transformacion } from '../../Interfaces/transformacion';
import { Subscription } from 'rxjs';

@Component({
  selector: 'listar-transformaciones',
  templateUrl: './listar-transformaciones.component.html',
  styleUrls: ['./listar-transformaciones.component.css']
})
export class ListarTransformacionesComponent {
  constructor(private servicioComunicaTransformacion: ComunicaComponenteTransformacionService) { } 

  public transformaciones: Transformacion[] = [];

  private subscription: Subscription = new Subscription(); 
  ngOnInit(): void {
    this.subscription = this.servicioComunicaTransformacion.transformaciones$.subscribe((transformaciones) => {
      this.transformaciones = transformaciones;
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  eliminarTransformacion(indice: number): void {
    this.servicioComunicaTransformacion.eliminarTransformacion(indice);
  }
}
