export interface Transformacion {
    id?: number,
    name?: string,
    ki?: string,
    image?: string
}