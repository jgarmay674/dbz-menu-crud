import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaginaPrincipalComponent } from './crud/paginas/pagina-principal/pagina-principal.component';
import { PaginaDetallePersonajeComponent } from './crud/paginas/detalle-personaje/detalle-personaje.component';
import { PaginaDetallePlanetaComponent } from './crud/paginas/detalle-planeta/detalle-planeta.component';
import { PaginaDetalleTransformacionComponent } from './crud/paginas/detalle-transformacion/detalle-transformacion.component';
import { LoginComponent } from './crud/paginas/login/login.component';
import { RegistroComponent } from './crud/paginas/registro/registro.component';

const routes: Routes = [
  { path: '', redirectTo: '/principal', pathMatch: 'full' },
  { path: 'principal', component: PaginaPrincipalComponent },
  { path: 'login', component: LoginComponent }, // Ruta para login
  { path: 'registro', component: RegistroComponent }, // Ruta para registro
  { path: 'personaje/:id', component: PaginaDetallePersonajeComponent},
  { path: 'planeta/:id', component: PaginaDetallePlanetaComponent},
  { path: 'transformacion/:id', component: PaginaDetalleTransformacionComponent},
  { path: '**', redirectTo: '/principal'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
